import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

public class LoginPageTest {

    public WebDriver driver;

    @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.chrome.driver",
                "PATH_TO_CHROMEDRIVER");
        driver = new ChromeDriver();
        driver.get("https://qajobbyapp.ccbp.tech/login");
    }

    @AfterMethod
    public void tearDown() {
        driver.quit();
    }

    @Test(priority = 1)
    public void testLoginWithEmptyInputs() {
        WebElement loginButton = driver.findElement(By.className("login-button"));
        loginButton.click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("error-message")));

        WebElement errorMessage = driver.findElement(By.className("error-message"));
        String actualErrorMessage = errorMessage.getText();

        Assert.assertEquals(actualErrorMessage, "*Username or password is invalid",
                "Error text with empty input fields does not match");
    }

    @Test(priority = 2)
    public void testLoginWithEmptyUsername() {
        WebElement passwordInputField = driver.findElement(By.id("passwordInput"));
        passwordInputField.sendKeys("rahul@2021");

        WebElement loginButton = driver.findElement(By.className("login-button"));
        loginButton.click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("error-message")));

        WebElement errorMessage = driver.findElement(By.className("error-message"));
        String actualErrorMessage = errorMessage.getText();

        Assert.assertEquals(actualErrorMessage, "*Username or password is invalid",
                "Error text with empty username do not match");
    }

    @Test(priority = 3)
    public void testLoginWithEmptyPassword() {
        WebElement usernameInputField = driver.findElement(By.id("userNameInput"));
        usernameInputField.sendKeys("rahul");

        WebElement loginButton = driver.findElement(By.className("login-button"));
        loginButton.click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("error-message")));

        WebElement errorMessage = driver.findElement(By.className("error-message"));
        String actualErrorMessage = errorMessage.getText();

        Assert.assertEquals(actualErrorMessage, "*Username or password is invalid",
                "Error text with empty password do not match");
    }

    @Test(priority = 4)
    public void testLoginWithInvalidCreds() {
        WebElement usernameInputField = driver.findElement(By.id("userNameInput"));
        usernameInputField.sendKeys("rahul");

        WebElement passwordInputField = driver.findElement(By.id("passwordInput"));
        passwordInputField.sendKeys("rahul");

        WebElement loginButton = driver.findElement(By.className("login-button"));
        loginButton.click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("error-message")));

        WebElement errorMessage = driver.findElement(By.className("error-message"));
        String actualErrorMessage = errorMessage.getText();

        Assert.assertEquals(actualErrorMessage, "*username and password didn't match",
                "Error text with invalid password do not match");
    }

    @Test(priority = 5)
    public void testLoginWithValidCreds() {
        WebElement usernameInputField = driver.findElement(By.id("userNameInput"));
        usernameInputField.sendKeys("rahul");

        WebElement passwordInputField = driver.findElement(By.id("passwordInput"));
        passwordInputField.sendKeys("rahul@2021");

        WebElement loginButton = driver.findElement(By.className("login-button"));
        loginButton.click();

        String expectedUrl = "https://qajobbyapp.ccbp.tech/";

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.urlToBe(expectedUrl));

        String actualURL = driver.getCurrentUrl();
        Assert.assertEquals(actualURL, expectedUrl, "URLs do not match");
    }
}